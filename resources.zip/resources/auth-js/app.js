require('./bootstrap');

require('./components/App');
