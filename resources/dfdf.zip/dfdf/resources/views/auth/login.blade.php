@extends('layouts.front')

@section('content')

<style>
    .style_rtl{
        text-align: right;
    }
    .style_lrt{
        text-align: left;
    }
       
    </style>
<div class="container" >

    <div class="row">
        <form class="form-signin" id="form" method="POST" action="{{ route('login') }}">
            {{ csrf_field() }}

            @php
                $pwd = '';
                $email = '';
            @endphp

     

            <div class="col-sm-9 col-md-7 col-lg-5 mx-auto shadow-lg  mb-5 bg-white rounded mt-3" >
                <div class="card card-signin">
                    <div class="card-body">
                        <div class="card-title p-4">
                            <h5 style="color:white;">
                                {{ trans('data.Log_in_to_the_engineering_offices_system') }}
                            </h5>
                        </div>
                        <div style="padding:20px;">
                           <div class="form-outline mb-1">
                                <input type="text" id="inputEmail" name="email_id_card" class="form-control form-control-lg" placeholder="{{ trans('data.email_or_id_card') }}"  required  ><br>
                                @if ($errors->has('email'))
                                    <span class="help-block  text-danger">
                                        <small class="help-text span-email" span-email>
                                            {{ $errors->first('email') }}
                                        </small>
                                    </span>
                                @endif
                            </div>
                            <div class="form-outline mb-1">
                                <input type="password" name="password" id="inputPassword" class="form-control form-control-lg" placeholder="{{ trans('data.password') }}" value ="{{$pwd}}"  required ><br>
                                @if ($errors->has('password'))
                                    <span class="help-block text-danger">
                                        <small class="help-text">
                                            {{ $errors->first('password') }}
                                        </small>
                                    </span>
                                @endif
                            </div>
                            <div class="form-outline mb-1">
                            <select name="user_type" id="user_type"  class="form-control form-control-lg"   style="display:none" >
                            
                                    <!-- @foreach(array_keys(config('constants.user_types'))  as $type)
                                        <option value="{{$type}}" >{{config('constants.user_types')[$type]}} </option>
                                    @endforeach -->
                                </select>
                                @if ($errors->has('user_type'))
                                    <span class="help-block text-danger">
                                        <small class="help-text">
                                            {{ $errors->first('user_type') }}
                                        </small>
                                    </span>
                                @endif
          
                            </div>

                            <!-- <div class="form-outline mb-1">
                            <select name="type_name" id="type_name"   class="form-control form-control-lg" style="display: none;margin-top:4%;" >
                                </select>
                                @if ($errors->has('user_type'))
                                    <span class="help-block text-danger">
                                        <small class="help-text">
                                            {{ $errors->first('user_type') }}
                                        </small>
                                    </span>
                                @endif
                            </div> -->
                            
                            <div class="custom-control custom-checkbox mb-3">
                                <input type="checkbox" class="custom-control-input" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                                <label class="custom-control-label" for="remember">
                                    {{__('data.remember_me')}}
                                </label>
                            </div>
                            <br>
                            <button class="btn btn-lg btn-block text-uppercase" style="background-color:#06706d;color:white;" id="submit" type="submit">
                             
                             {{__('data.login')}}
                            </button>
                            <a class="btn btn-link d-block text-center" style="color:#06706d;" href="{{ route('password.request') }}">
                                
                               
                                {{__('data.forget_password')}}
                            </a>
                            @if(config('constants.enable_client_signup'))
                                <a class="btn btn-link d-block text-center py-0"  style="color:#06706d;"  href="{{ route('register')}}">
                                    <!-- //route('client.register-form')  -->
                                {{__('data.register')}}
                                </a>
                            @endif
                        </div>
                        <div class="card-title text-center"style="margin-bottom: 0px;">
                            <span style="font-size:12px; color:white;">
                                {{ trans('data.all_rights_are_save') }} <b>2020</b>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    @if (session('status'))
        <div class="row">
            <div class="col-md-12">
                <div class="alert @if(session('status.success')) alert-success @else alert-danger @endif alert-dismissible fade show mt-5" role="alert">
                  {{ session('status.msg') }}
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
            </div>
        </div>
    @endif
    @if(config('app.env') == 'demo')
        <div class="row justify-content-md-center">
            <div class="col-md-4">
                <p class="text-center text-danger">Demo Logins</p>
                <table class="table table-sm">
                    <tr>
                        <th>User Role</th>
                        <th>Email</th>
                        <th>Password</th>
                        <th>#</th>
                    </tr>
                    <tr>
                        <th>Admin</th>
                        <td>admin@example.com</td>
                        <td>123456</td>
                        <td>
                            <button class="btn btn-sm btn-success copy" data-email="admin@example.com" data-pwd="123456">Login</button>
                        </td>
                    </tr>
                    <tr>
                        <th>Employee</th>
                        <td>employee@example.com</td>
                        <td>123456</td>
                        <td>
                            <button class="btn btn-sm btn-success copy" data-email="employee@example.com" data-pwd="123456">Login</button>
                        </td>
                    </tr>
                    <tr>
                        <th>Customer / Client</th>
                        <td>customer@example.com</td>
                        <td>123456</td>
                        <td>
                            <button class="btn btn-sm btn-success copy" data-email="customer@example.com" data-pwd="123456">Login</button>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    @endif

</div>
@endsection

@section('javascript')
<style>


  .error{
    color: red;
  }
  /* label,
  input,
  button {
    border: 0;
    margin-bottom: 3px;
    display: block;
    width: 100%;
  }
 .common_box_body {
    padding: 15px;
    border: 12px solid #28BAA2;
    border-color: #28BAA2;
    border-radius: 15px;
    margin-top: 10px;
    background: #d4edda;
} */
</style>
@section('javascript')
<!-- <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script> -->
    <script type="text/javascript">
const isEmpty = str => !str.trim().length;

//if()

$('input[type=text]').addClass('textbox');
var flag=false
$(document).ready(function(){



    if(document.documentElement.lang=="ar"){
        $(".container").css("text-align", "right");
        $("#user_type").css("text-align", "right");
        $('input[type=text]').addClass('style_rtl');
        $('input[type=email]').addClass('style_rtl');
        $('input[type=number]').addClass('style_rtl');
        $('input[type=password]').addClass('style_rtl');
    }
    else{
        $(".container").css("text-align", "left");
        $("#user_type").css("text-align", "left");
        $('input[type=text]').addClass('style_ltr');
        $('input[type=email]').addClass('style_ltr');
        $('input[type=number]').addClass('style_ltr');
        $('input[type=password]').addClass('style_rtl');
     
    }

        $("#inputEmail").on("change",function() {
        var email = $("#inputEmail").val();
        var password = $("#inputPassword").val();
        if(!isEmpty(email) && !isEmpty(password)){
            $('#user_type').children().remove();
            $("#user_type").prop('required',false);
            $("#user_type").hide(); 
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content')
                $.ajax({
                        headers: {
                        'X-CSRF-TOKEN': CSRF_TOKEN
                        },
                        type:'POST',
                        url:"{{ route('getType.post') }}",
                        data:{email: email,password:password},
                        success:function(result){
                          
                            console.log(result.length)
                            var options = "";
                            
                                    if (result.length > 1){
                                        flag=false;
                                        $("#user_type").show(); 
                                        $('#user_type').children().remove();
                                       $("#user_type").prop('required',true);
                                       var options1 = `<option value="" disabled selected> ${document.documentElement.lang=="ar" ?  "اختر نوع المستخدم" : "choose type"}</option>`;
                                        $("#user_type").append(options1);
                                            for (var i = 0; i < result.length; i++) {
                                            options += `<option value=${result[i].type}>${result[i].name}</option>`;//<--string 
                                            }
                                            $("#user_type").append(options);
                                    }
                                    else{
                                        flag=true
                                        $('#user_type').children().remove();
                                        $("#user_type").prop('required',false);
                                        $("#user_type").hide(); 
                                    }
                            }
                     
                    });
        }
   });
   $("#inputPassword").on("change",function() {
        var email = $("#inputEmail").val();
        var password = $("#inputPassword").val();
        if(!isEmpty(email) && !isEmpty(password)){
            $('#user_type').children().remove();
            $("#user_type").prop('required',false);
            $("#user_type").hide(); 
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content')
                $.ajax({
                        headers: {
                        'X-CSRF-TOKEN': CSRF_TOKEN
                        },
                        type:'POST',
                        url:"{{ route('getType.post') }}",
                        data:{email: email,password:password},
                        success:function(result){
                           
                            console.log(result.length)
                            var options = "";
                                    if (result.length > 1){
                                        flag=false
                                        $("#user_type").show(); 
                                        $("#user_type").prop('required',true);
                                        var options1 = `<option value="" disabled selected> ${document.documentElement.lang=="ar" ?  "اختر نوع المستخدم" : "choose type"}</option>`;
                                            $("#user_type").append(options1);
                                                for (var i = 0; i < result.length; i++) {
                                                options += `<option value=${result[i].type}>${result[i].name}</option>`;//<--string 
                                                }
                                                $("#user_type").append(options);
                                            }
                                    else{ 
                                        flag=true
                                        $('#user_type').children().remove();
                                        $("#user_type").prop('required',false);
                                        $("#user_type").hide(); 

                                   }
                            }
                    
                     
                    });
        }
   });

 });
 


    $('#form').submit(function() {
        if(flag){
            return flag;
        }
        else{
            return $("#user_type option:selected").length> 0
        }
    })
         


       $('button.copy').click(function(){
            $('input#inputEmail').val($(this).data('email'));
            $('input#inputPassword').val($(this).data('pwd'));
            $('button#submit').trigger('click');
        });








    </script>
@endsection